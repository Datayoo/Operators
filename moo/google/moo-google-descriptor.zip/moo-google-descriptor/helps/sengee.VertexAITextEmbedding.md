# VertexAITextEmbedding

​	**标签：** 

### 描述

​	调用Google Vertex AI的接口对文本进行Embedding。允许提交的最大Tokens数为3072。若超过提交限制输入会以静默方式截断。可设置autoTruncate为false关闭静默截断。

#### 前置条件

​	已申请谷歌云的API访问账号。该账号需要信用卡认证。账号认证通过后，在账号对应的控制台中创建一个项目，项目的ID会在算子中使用到。进入项目控制台，选择"API和服务"菜单，选择“库”菜单，启用Vertex API接口；再选择“凭据”菜单，点击“管理服务”。进入“服务账号”界面后，创建一个服务账号，保存该服务账号对应的json描述文件。使用该json描述文件生成可以访问Vertex API的Access Token。该Access Token的有效周期为1小时，使用时需要注意，需要经常性的去更新其在资源账号中预设的账号。

​	基于服务账号json描述文件生成Access Token的Java代码实现如下：

```
GoogleCredentials credentials = GoogleCredentials.fromStream(jsonStream)
        .createScoped("https://www.googleapis.com/auth/cloud-platform");
credentials.refreshIfExpired();
credentials.getAccessToken().getTokenValue();
```



### 输入端口

#### dataIn

​	数据输入端口

​	**输入类型**：/

### 输出端口

#### dataOut

​	数据输出端口，输出文本的分类信息

​	**输出类型**：/embedding/txt

### 参数

#### settingService

​	选择Http代理服务。Http代理服务在"环境管理">"服务配置"中预先配置定义。

​	**是否可选**: 是

#### authSettingsService

​	访问Vertex AI接口所用的账号信息。该账号是在"个人设置">"资源账号"模块中预先配置定义的。

​	**是否可选**: 否

#### location

​	提供API服务设备所在的区域，该区域为谷歌云系统提供的区域，如：us-central1。

​	**数据类型**: String

​	**是否可选**: 否

#### projectId

​	项目ID。

​	**数据类型**: String

​	**是否可选**: 否

#### modelName

​	模型的名称，即希望使用的文本Embedding模型的名称。使用者需要自己确保填入算子的模型为对应的文本Embedding模型。Vertex支持的Embedding模型包括：textembedding-gecko@latest 与textembedding-gecko-multilingual@latest两种。textembedding-gecko@latest主要用于英文的Embedding。textembedding-gecko-multilingual@latest则用于其他语种的Embedding。其他语种的类型包括：Afrikaans、Albanian、Amharic、Arabic、Armenian、Azerbaijani、Basque、Belarusian、Bengali、Bulgarian、Burmese、Catalan、Cebuano、Chichewa、Chinese、Corsican、Czech、Danish、Dutch、English、Esperanto、Estonian、Filipino、Finnish、French、Galician、Georgian、German、Greek、Gujarati、Haitian Creole、Hausa、Hawaiian、Hebrew、Hindi、Hmong、Hungarian、Icelandic、Igbo、Indonesian、Irish、Italian、Japanese、Javanese、Kannada、Kazakh、Khmer、Korean、Kurdish、Kyrgyz、Lao、Latin、Latvian、Lithuanian、Luxembourgish、Macedonian、Malagasy、Malay、Malayalam、Maltese、Maori、Marathi、Mongolian、Nepali、Norwegian、Pashto、Persian、Polish、Portuguese、Punjabi、Romanian、Russian、Samoan、Scottish Gaelic、Serbian、Shona、Sindhi、Sinhala、Slovak、Slovenian、Somali、Sotho、Spanish、Sundanese、Swahili、Swedish、Tajik、Tamil、Telugu、Thai、Turkish、Ukrainian、Urdu、Uzbek、Vietnamese、Welsh、West Frisian、Xhosa、Yiddish、Yoruba、Zulu等。

​	两种模型的维度均为768

​	**数据类型**: String

​	**是否可选**: 否

​	**缺省值：**textembedding-gecko-multilingual@latest

#### task_type

​	向量作用的任务类型。支持的类型包括：RETRIEVAL_QUERY(查询向量)、RETRIEVAL_DOCUMENT(底库向量)、SEMANTIC_SIMILARITY(相似度向量)、CLASSIFICATION(分类向量)、CLUSTERING(聚合向量)

​	**数据类型**: String

​	**是否可选**: 否

​	**缺省值：**RETRIEVAL_DOCUMENT

#### autoTruncate

​	文本超长自动截断

​	**数据类型**: Boolean

​	**是否可选**: 否

​	**缺省值：**true

#### idColumn

​	文本的ID列。算子完成文本Embedding后，输出文本的Embedding信息，会附带该ID列的值，以便标识输出的Embedding信息与输入的文本信息间的对应关系。

​	**数据类型**: String

​	**是否可选**: 否

#### columnName

​	待进行文本Embedding的文本列名。算子将对该列中的文本信息进行embedding。

​	**数据类型**: String

​	**是否可选**: 否

