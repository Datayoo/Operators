#!/bin/bash
 
timestamp=$(date +%s)

script_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

cur_dir=$(cd "$(dirname "$0")"; pwd)

# jar
\cp -r -f -p $cur_dir/lib/* /home/datayoo/app/authx/lib/
cp -r /$script_dir/app/oyez/conf/lib.txt /home/datayoo/app/oyez/conf/lib.txt

