#!/bin/bash
 
timestamp=$(date +%s)

script_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

cur_dir=$(cd "$(dirname "$0")"; pwd)

# jar
\cp -r -f -p $cur_dir/lib/* /home/datayoo/app/authx/lib/

