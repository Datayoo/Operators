# TencentHunYuanTextEmbedding

​	**标签：** 

### 描述

​	腾讯混元文本Embedding，Embedding长度1024。

#### 前置条件

​	已申请腾讯的访问账号。账号申请地址：https://cloud.tencent.com/document/product/378/17985；混元服务开通：https://console.cloud.tencent.com/hunyuan。

### 输入端口

#### dataIn

​	数据输入端口

​	**输入类型**：/

### 输出端口

#### dataOut

​	数据输出端口，输出文本的向量信息

​	**输出类型**：/embedding/txt

### 参数

#### settingService

​	选择Http代理服务。Http代理服务在"环境管理">"服务配置"中预先配置定义。

​	**是否可选**: 是

#### authSettingsService

​	访问腾讯混元接口所用的账号信息。该账号是在"个人设置">"资源账号"模块中预先配置定义的。填写资源账号时，账号名填写security id，访问token填写security key。

​	**是否可选**: 否

#### idColumn

​	文本的ID列。算子完成文本Embedding后，输出文本的Embedding信息，会附带该ID列的值，以便标识输出的Embedding信息与输入的文本信息间的对应关系。

​	**数据类型**: String

​	**是否可选**: 否

#### columnName

​	待进行文本Embedding的文本列名。算子将对该列中的文本信息进行embedding。

​	**数据类型**: String

​	**是否可选**: 否

