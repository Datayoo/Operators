# OpenAITextGenerator

​    **标签：**

### 描述

​	根据用户输入的工作意图，通过OpenAI大语言模型完成工作。OpenAI大语言模型能够在用户自然语言输入的基础上，通过自然语言理解和语义分析，理解用户意图，在不同领域、任务内为用户提供服务和帮助。您可以通过提供尽可能清晰详细的指令，来获取更符合您预期的结果。

#### 前置条件

​	已申请Open AI的访问账号。账号申请地址https://auth0.openai.com/

### 输入端口

#### promptIn

​	提示输入端口

​    **输入类型**：/prompt

### 输出端口

#### resultOut

​	结果输出端口

​    **输出类型**：/textGen

### 参数

#### settingService

​    选择Http代理服务。Http代理服务在"环境管理">"服务配置"中预先配置定义。

​    **是否可选**: 是

#### authSettingsService

​    访问OpenAI接口所用的账号信息。该账号是在"个人设置">"资源账号"模块中预先配置定义的。

​    **是否可选**: 否

#### requestUrl 

 	服务的请求地址，缺省为https://api.openai.com/v1/completions。

​    **数据类型**: String

​    **是否可选**: 否

#### modelName

模型名称。可用模型有：o1，o1-preview，o1-mini, gpt-4o, gpt-4o-mini, gpt-4-turbo, gpt-4-turbo-preview, gpt-4, gpt-3.5-turbo, gpt-3.5-turbo-instruct等

| 模型名                 | 最大上下文长度 | 最大输出长度 |
| ---------------------- | -------------- | ------------ |
| o1                     | 200,000        | 100,000      |
| o1-preview             | 128,000        | 100,000      |
| o1-mini                | 128,000        | 100,000      |
| gpt-4o                 | 128,000        | 16,384       |
| gpt-4o-mini            | 128,000        | 16,384       |
| gpt-4-turbo            | 128,000        | 4,096        |
| gpt-4-turbo-preview    | 128,000        | 4,096        |
| gpt-4                  | 8,192          | 8,192        |
| gpt-3.5-turbo          | 16,385         | 4,096        |
| gpt-3.5-turbo-instruct | 4,096          | 4,096        |

​    **数据类型**: String

​    **是否可选**: 否

​    **缺省值：**text-davinci-003

#### tokenEncoder

​	token编码器。可用编码模型有：CL100K_BASE、P50K_EDIT、P50K_BASE、R50K_BASE。当用户输入的模型不是算子提供的标准模型，需自行设置模型的编码器。系统将根据这些信息自动计算Prompt请求是否超过了模型支持的最大上下文长度。

​    **数据类型**: String

​    **是否可选**: 否

​    **缺省值：**CL100K_BASE

#### maxContextLength

​	模型支持的最大上下文长度。当用户输入的模型不是算子提供的标准模型，需自行设置模型的编码器。系统将根据这些信息自动计算Prompt请求是否超过了模型支持的最大上下文长度。

​    **数据类型**: Integer

​    **是否可选**: 否

​    **缺省值：**8193

#### temperature

 随即度调节指数。

​    **数据类型**: UDouble

​    **是否可选**: 否

​    **缺省值：**0

#### top_p

 核心采样指数。

​    **数据类型**: UDouble

​    **是否可选**: 否

​    **缺省值：**1.0

#### presence_penalty

​    '存在'惩罚。

​    **数据类型**: UDouble

​    **是否可选**: 否

​    **缺省值：**0

#### frequency_penalty

​    '频次'惩罚。

​    **数据类型**: UDouble

​    **是否可选**: 否

​    **缺省值：**0