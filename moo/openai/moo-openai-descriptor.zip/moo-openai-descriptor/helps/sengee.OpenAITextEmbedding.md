# OpenAITextEmbedding

​	**标签：** 

### 描述

​	OpenAI文本Embedding。

#### 前置条件

​	已申请Open AI的访问账号。账号申请地址https://auth0.openai.com/

### 输入端口

#### dataIn

​	数据输入端口

​	**输入类型**：/

### 输出端口

#### dataOut

​	数据输出端口，输出文本的分类信息

​	**输出类型**：/embedding/txt

### 参数

#### settingService

​	选择Http代理服务。Http代理服务在"环境管理">"服务配置"中预先配置定义。

​	**是否可选**: 是

#### authSettingsService

​	访问OpenAI接口所用的账号信息。该账号是在"个人设置">"资源账号"模块中预先配置定义的。

​	**是否可选**: 否

#### modelName

​	模型的名称，即希望使用的文本Embedding模型的名称。使用者需要自己确保填入算子的模型为对应的文本分类模型。

​	**数据类型**: String

​	**是否可选**: 否

#### idColumn

​	文本的ID列。算子完成文本Embedding后，输出文本的Embedding信息，会附带该ID列的值，以便标识输出的Embedding信息与输入的文本信息间的对应关系。

​	**数据类型**: String

​	**是否可选**: 否

#### columnName

​	待进行文本Embedding的文本列名。算子将对该列中的文本信息进行embedding。

​	**数据类型**: String

​	**是否可选**: 否

