# HuggingFaceSpeechToText

​	**标签：** 

### 描述

​	调用HuggingFace网站提供的语音识别模型接口，实现语音转文字。使用选中的HuggingFace网站上的具体语音识别模型完成语音转文字。模型细节可通过对应模型的模型选项卡了解详情。

#### 前置条件

​	申请HuggingFace相关账号，申请链接：https://huggingface.co/join。

### 输入端口

#### streamIn

​	数据输入端口

​	**输入类型**：/dataStream

### 输出端口

#### dataOut

​	数据输出端口，输出语音中识别到的文本信息

​	**输出类型**：/d1RegionFeature

### 参数

#### settingService

​	选择Http代理服务。Http代理服务在"环境管理">"服务配置"中预先配置定义。

​	**是否可选**: 是

#### authSettingsService

​	访问HuggingFace接口所用的账号信息。该账号是在"个人设置">"资源账号"模块中预先配置定义的。

​	**是否可选**: 否

#### modelName

​	模型的名称，即希望使用的音频分类模型的名称。如：openai/whisper-small。使用者需要自己确保填入算子的模型为对应的语音识别模型。

​	**数据类型**: String

​	**是否可选**: 否
