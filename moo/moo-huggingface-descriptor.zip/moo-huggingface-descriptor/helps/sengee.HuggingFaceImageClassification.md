# HuggingFaceImageClassification

​	**标签：** 

### 描述

​	调用HuggingFace网站提供的模型分类接口，实现图像分类。使用选中的HuggingFace网站上的具体模型对图像进行分类，分类标准以选中的模型为准。模型细节可通过对应模型的模型选项卡了解详情。

#### 前置条件

​	申请HuggingFace相关账号，申请链接：https://huggingface.co/join。

### 输入端口

#### streamIn

​	数据输入端口

​	**输入类型**：/dataStream

### 输出端口

#### dataOut

​	数据输出端口，输出图片的分类信息

​	**输出类型**：/classification/stream

### 参数

#### settingService

​	选择Http代理服务。Http代理服务在"环境管理">"服务配置"中预先配置定义。

​	**是否可选**: 是

#### authSettingsService

​	访问HuggingFace接口所用的账号信息。该账号是在"个人设置">"资源账号"模块中预先配置定义的。

​	**是否可选**: 否

#### modelName

​	模型的名称，即希望使用的图像分类模型的名称。如：microsoft/resnet-50。使用者需要自己确保填入算子的模型为对应的图像分类模型。

​	**数据类型**: String

​	**是否可选**: 否

#### use_cache

​	是否使用模型中缓存的结果。HuggingFace网站会缓存不会发生改变的计算结果，以便提高接口的请求效率。

​	**数据类型**: Boolean

​	**是否可选**: 否

​	**缺省值**: true

#### wait_for_model

​	是否等待HuggingFace网站加载指定的模型。被用户调用的模型并不总是保持服务状态，HuggingFace网站会关停某些不常用的模型服务。若此时调用接口访问模型，接口就会返回模型未装载的错误。此时，设定该值为true，可确保接口调用成功。接口会等待HuggingFace启动模型后再完成模型调用。

​	**数据类型**: Boolean

​	**是否可选**: 否

​	**缺省值**: false
