# PythonScript

​	**标签：** 

### 描述

​	python脚本算子。支持内嵌一段Python脚本对输入的数据集进行处理。当系统内置算子无法满足对数据的处理要求时，可以通过该算子扩展数据处理逻辑。内嵌脚本必须遵循至少包括以下两个函数中的一个，processRows(rowSet, dataListener)或processRow(row, dataListener)。若两个函数同时存在，则优先使用processRows。

​	processRows表示对传入的集合进行处理，rowSet是一个字典类型的链表，其中的每个字典对象代表一条记录。dataListener是一个回调接口对象，处理程序可以通过调用该接口将处理结果返回给算子。代码示例如下：

```
def processRows(rowSet, dataListener):
    for row in rowSet:
        content = row['dataBlock']
        System.out.println(content)
        person = {"name": "a", "gender": "女", "party": "共和党"}
        dataListener.onData("dataOut", person)
    return;
```

​	processRow表示对传入的记录进行处理，row是一个字典，代表一条记录。dataListener是一个回调接口对象，处理程序可以通过调用该接口将处理结果返回给算子。代码示例如下：

```
def processRow(row, dataListener):
    content = row['dataBlock']
    System.out.println(content)
    person = {"name": "a", "gender": "女", "party": "共和党"}
    dataListener.onData("dataOut", person)
    org = {"name": "总部", "address": "北京市海淀区", "phone": "010-23344444",
           "fax": "010-23242334"}
    dataListener.onData("orgOut", org)
    return
```

​	dataListener对象内置onData(portName, row)函数，脚本通过调用该接口将数据写出到指定的端口。portName表示数据要写出的端口的名字，该端口必须存在于outputSettings参数定义的端口中；row表示一条处理后的数据，字典对象，其结构应符合对应输出端口的columnSetMetas属性定义的结构。

​	当前仅支持python3。

### 输入端口

#### dataIn

​	数据输入端口

​	**输入类型**：/

### 输出端口

​	不定，由参数outputSettings定义

### 参数

#### outputSettings

​	输出端口及结构定义

##### portName

​	输出端口名。

​	**数据类型**: String

​	**是否可选**: 否

##### flowDataType

​	输出数据类型。

​	**数据类型**: String

​	**是否可选**: 否

##### columnSetMetas

​	输出集合结构定义。

​	**是否可选**: 否

#### script

​	脚本定义。

##### script

​	脚本代码。

​	**数据类型**: String

​	**是否可选**: 否

##### dependencies

​	脚本运行时的依赖。

###### name

​	依赖的名称。

​	**数据类型**: String

​	**是否可选**: 否

###### package

​	是否为代码包。

​	**数据类型**: boolean

​	**是否可选**: 否

###### path

​	依赖文件或包的路径。

​	**数据类型**: String

​	**是否可选**: 否