# FeatureStatisticor

​	**标签：** 

### 描述

​	特征统计。对输入数据集的数据特征进行统计。输出为：

| 列名             | 说明                                                 |
| ---------------- | ---------------------------------------------------- |
| colnName         | 特征的名字                                           |
| colnType         | 特征的数据类型                                       |
| valCount         | 特征中值的数量                                       |
| missingValCount  | 特征中缺失值的数量                                   |
| missingValRatio  | 特征中缺失值的占比                                   |
| distinctValCount | 特征中去重值的数量                                   |
| distinctValRatio | 特征中去重值的占比                                   |
| valMax           | 最大值(最多值)及数量，非数值特征时含义为数量最多的值 |
| valMin           | 最小值(最少值)及数量，非数值特征时含义为数量最少的值 |
| valMode          | 众数及数量                                           |
| valMean          | 均值(仅数值类特征)                                   |
| valMedian        | 中位数(仅数值类特征)                                 |
| valVariance      | 方差(仅数值类特征)                                   |
| valStdDev        | 标准方差(仅数值类特征)                               |
| valSkewness      | 偏度(仅数值类特征)                                   |
| valKurtosis      | 峰度(仅数值类特征)                                   |



### 输入端口

#### dataIn

​	数据输入端口

​	**输入类型**：/

### 输出端口

#### dataOut

​	数据输出端口

​	**输出类型**：/

### 参数

#### rowCount

​	特征统计可以统计的最大记录数。当该值为0时，表示不做最大记录数限制，对全部数据进行统计。

​	**数据类型**: Uinteger

​	**是否可选**: 否

​	**缺省值**: 0
